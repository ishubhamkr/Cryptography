#include <bits/stdc++.h>
#include <cmath>
using namespace std;
int main()
{
    long long int a,b,g,p;
    long long int pa,pb,sa,sb;
    cout<<"Enter a prime number:";
    cin>>p;
    cout<<"\n"<<"Enter a generator G between 0 to "<<p<<":";
    cin>>g;
    cout<<"\n"<<"Enter the private key of user A:";
    cin>>a;
    cout<<"\n"<<"Enter the private key of user B:";
    cin>>b;
    pa=pow(g,a);
    pa=pa%p;
    pb=pow(g,b);
    pb=pb%p;
    cout<<"Public key of user A: "<<pa<<"\n";
    cout<<"Public key of user B: "<<pb<<"\n";
    sa=pow(pb,a);
    sa=sa%p;
    sb=pow(pa,b);
    sb=sb%p;
    cout<<"Secret key for user A: "<<sa<<"\n";
    cout<<"Secret key for user B: "<<sb<<"\n";
}
