import sys

def lcm(a, b):
    return a * b / gcd(a, b)

def gcd(a,b):
    while b > 0:
        a, b = b, a % b
    return a


p = int(input("Enter a prime number 'p':"))
q = int(input("Enter a prime number 'q':"))
M = p*q
seed = int(input("Enter the seed value:"))
N = int(input("Enter the number of required numbers:")) 


if (len(sys.argv)>1):
    N=int(sys.argv[1])


print("\np:\t",p)
print("q:\t",q)

print("M:\t",M)
print("Seed:\t",seed)

x = seed

bit_output = ""
for _ in range(N):
    x = x*x % M
    b = x % 2
    bit_output += str(b)
print(bit_output)

print("\nNumber of zeros:\t",bit_output.count("0"))

print("Number of ones:\t\t",bit_output.count("1"))

xi=''

print("\nPredicting 1st 30 with Euler's Theorem:")
for i in range(1,30):
    val=pow(2,int(i),int(lcm(p-1,p-1)))
    xi += str(pow(int(seed),int(val),int(M)) %2)
print(xi)
