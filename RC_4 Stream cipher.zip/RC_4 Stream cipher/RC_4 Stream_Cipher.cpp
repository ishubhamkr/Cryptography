#include <iostream>
#include <string>
#include<vector>
using namespace std;

vector<int> permute(vector<int>, vector<int>);
string keygen(vector<int>s , vector<int> t, string p);
string encrypt(vector<int>s , vector<int> t, string p);
string decrypt(vector<int>s, vector<int> t, string p);

string decrypt(vector<int>s, vector<int> t, string p) {
	int i,j,tmp,k,b,c;
	i=0;
	j=0;
	tmp=0;
	k=0;
	int * plain = new int[p.length()];
	string plain_T;

	for (int r = 0; r < p.length(); r++)
    {
		i = (i + 1) % 256;
		j = (j + s[i]) % 256;
		b = s[i];
		s[i] = s[j];
		s[j] = b;

		tmp = (s[i] + s[j]) % 256;
		k = s[tmp];
		c = ((int)p[r] ^ k);
		plain[r] = c;
		plain_T += (char)plain[r];
	}
	return plain_T;
}

string encrypt(vector<int>s, vector<int> t, string p) {

	int i,j,tmp,k,b,c;
	i=0;
	j=0;
	tmp=0;
	k=0;

	int * cipher = new int [p.length()];
	string cipher_T;
    for (int r = 0; r < p.length(); r++)
    {
		i = (i + 1) % 256;
		j = (j + s[i]) % 256;
		b = s[i];
		s[i] = s[j];
		s[j] = b;

		tmp = (s[i] + s[j]) % 256;
		k = s[tmp];
		c = ((int)p[r] ^ k);
		cipher[r] = c;
		cipher_T += (char)cipher[r];
	}
	cout << endl;
	return cipher_T;
}
string keygen(vector<int>s, vector<int> t, string p) {

	int i,j,tmp,k,b,c;
	i=0;
	j=0;
	tmp=0;
	k=0;

	int * cipher = new int [p.length()];
	string cipher_T;

	for (int r = 0; r < p.length(); r++)
    {

		i = (i + 1) % 256;
		j = (j + s[i]) % 256;
		b = s[i];
		s[i] = s[j];
		s[j] = b;
		tmp = (s[i] + s[j]) % 256;
		k = s[tmp];

		cout << k << " ";
    }
	cout << endl;
	return cipher_T;
}

vector<int> permute(vector<int> s, vector<int> t) {
	int j = 0;
	int tmp;
	for (int i = 0; i< 256; i++) {
		j = (j + s[i] + t[i]) % 256;

		tmp = s[i];
		s[i] = s[j];
		s[j] = tmp;
	}
	return s;
}

int main() {

	string plaintext;
	cout<<"Enter plain text:";
	cin >> plaintext;
	vector<int> S(256);
	vector<int> T(256);
	int key[256],i,n;
	cout<<"\nEnter the length of the key:";
	cin>>n;
	cout<<"\nEnter the key:";
	for(i=0;i<n;i++)
    {
        cin>>key[i];
    }
	int tmp = 0;
	for (int i = 0; i < 256;i++) {
		S[i] = i;
		T[i] = key[( i % (sizeof(key)/sizeof(*key)) )];
	}
	S = permute(S, T);
	string p = encrypt(S, T, plaintext);
    cout << "Message: " << plaintext << endl;
	cout << "Keys Generated for plaintext: ";
	cout<<keygen(S, T, plaintext)<<endl;
	cout << "Encrypted Message: " << " " << p << endl;
	cout << "Decrypted Message:  " << decrypt(S, T, p) << endl << endl;
	return 0;
}
